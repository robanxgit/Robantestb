module com.example.robantestb {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;

    opens com.example.robantestb to javafx.fxml;
    exports com.example.robantestb;
}