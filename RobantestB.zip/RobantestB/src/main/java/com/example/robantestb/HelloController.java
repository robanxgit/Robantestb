package com.example.robantestb;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class HelloController {
    public TextField username;
    public TextField password;
    public Label errormessage;
    @FXML
    private Label welcomeText;
    static int invalidReqcount=0;

    static String correctusername="Roban";
    static String correctpassword="1234";

    public void onloginButtonClick(ActionEvent actionEvent) {
        String usernameInput=username.getText();
        String passwordInput=password.getText();

        if (usernameInput.isEmpty()|| passwordInput.isEmpty()){
            errormessage.setText("Please provide username or password");
        }
        else if (invalidReqcount==5){
            errormessage.setText("Sorry, your account is locked!!!" );
        }
        else   if (usernameInput.equals(correctusername) && passwordInput.equals(correctpassword)){
            errormessage.setText("you are logged in succesfully");
            invalidReqcount=0;
        }
        else { errormessage.setText("Sorry, Invalid username or Password.");
            invalidReqcount++;
}
    }

}